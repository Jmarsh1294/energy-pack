Jmarsh Energy Items Test Pack

This pack currently contains one custom item model:
- jmarsh:grand_wand

Test command for Minecraft Java 1.21.4+:
/give @p minecraft:blaze_rod[minecraft:item_model="jmarsh:grand_wand"] 1

If the item appears as a missing model, make sure the resource pack is enabled and that the files are still in these paths:
assets/jmarsh/items/grand_wand.json
assets/jmarsh/models/item/grand_wand.json
assets/jmarsh/textures/item/grand_wand.png

Note: the uploaded Blockbench export only included handle, grip bands, and energy shaft. If you added a top socket/crystal afterward, re-export from Blockbench and replace assets/jmarsh/models/item/grand_wand.json and assets/jmarsh/textures/item/grand_wand.png.
